
#include <RcppArmadillo.h>
#include "progress.hpp"
#include "Rcpp/Rmath.h"
#include <bsvars.h>

#include "sample_hyper.h"
#include "sample_Q.h"
#include "sample_NIW.h"
#include "sample_SOE.h"

using namespace Rcpp;
using namespace arma;

// [[Rcpp::interfaces(cpp)]]
// [[Rcpp::export]]
arma::field<arma::mat> bsvar_sign_single_draw_cpp(
    const int &p,
    const arma::mat &Y,
    const arma::mat &X,
    const arma::cube &sign_irf,
    const arma::mat &sign_narrative,
    const arma::mat &sign_B,
    const arma::field<arma::mat> &Z,
    const int &Nf,
    const Rcpp::List &prior,
    const int &max_tries,
    const int idx
) {
  const int T = Y.n_rows;
  const int N = Y.n_cols;
  const int K = X.n_cols;

  mat hypers = as<mat>(prior["hyper"]);
  int prior_nu = as<int>(prior["nu"]);
  int post_nu = prior_nu + T;
  int n_tries;

  double w, mu, delta, lambda;

  vec hyper, psi;
  vec prior_v = as<mat>(prior["V"]).diag();

  mat B, Sigma, chol_Sigma, h_invp, Q, shocks;
  mat prior_V, prior_S, post_B, post_V, post_S;
  mat Ystar, Xstar, Yplus, Xplus;
  mat prior_B = as<mat>(prior["B"]);
  mat Ysoc = as<mat>(prior["Ysoc"]);
  mat Xsoc = as<mat>(prior["Xsoc"]);
  mat Ysur = as<mat>(prior["Ysur"]);
  mat Xsur = as<mat>(prior["Xsur"]);

  field<mat> result;

  hyper = hypers.col(hypers.n_cols > 1 ? idx : 0);
  mu = hyper(0);
  delta = hyper(1);
  lambda = hyper(2);
  psi = hyper.rows(3, N + 2);

  // update Minnesota prior
  prior_V = diagmat(prior_v % join_vert(lambda * lambda * repmat(1 / psi, p, 1),
                                        ones<vec>(K - N * p)));
  prior_S = diagmat(psi);

  // update dummy observation prior
  Ystar = join_vert(Ysoc / mu, Ysur / delta);
  Xstar = join_vert(Xsoc / mu, Xsur / delta);

  mat Y_scaled = Y;
  mat X_scaled = X;
  int covid = as<int>(prior["covid"]);
  vec sigma = ones<vec>(T);
  if (covid > 0 && covid <= T) {
    int c_idx = covid - 1;
    double s0 = hyper(N + 3);
    double s1 = hyper(N + 4);
    double s2 = hyper(N + 5);
    double rho = hyper(N + 6);

    if (c_idx < T) sigma(c_idx) = s0;
    if (c_idx + 1 < T) sigma(c_idx + 1) = s1;
    if (c_idx + 2 < T) sigma(c_idx + 2) = s2;
    for (int t = c_idx + 3; t < T; t++) {
      sigma(t) = 1.0 + (s2 - 1.0) * std::pow(rho, t - c_idx - 2);
    }

    Y_scaled.each_col() /= sigma;
    X_scaled.each_col() /= sigma;
  }

  Yplus = join_vert(Ystar, Y_scaled);
  Xplus = join_vert(Xstar, X_scaled);

  // posterior parameters
  result = niw_cpp(Yplus, Xplus, prior_B, prior_V, prior_S, prior_nu);
  post_B = result(0);
  post_V = result(1);
  post_S = result(2);
  post_nu = as_scalar(result(3));

  double log_w = -arma::datum::inf;
  n_tries = 0;

  while (std::isinf(log_w) and (n_tries < max_tries or max_tries == 0)) {

    checkUserInterrupt();

    // sample reduced-form parameters
    Sigma = iwishrnd(post_S, post_nu);
    chol_Sigma = chol(Sigma, "lower");

    double log_w_B = 0;
    if (Nf > 0) {
      arma::field<arma::mat> res_B = sample_restricted_B_cpp(post_B, post_V, Sigma, p, N, Nf, K);
      B = res_B(0);
      log_w_B = as_scalar(res_B(1));
    } else {
      B = rmatnorm_cpp(post_B, post_V, Sigma);
    }

    h_invp = inv(trimatl(chol_Sigma)); // lower tri, h(Sigma) is upper tri

    result = sample_Q(p, Y_scaled, X_scaled, B, h_invp, chol_Sigma, prior,
                      sign_irf, sign_narrative, sign_B, Z, Nf, 1);
    Q = result(0);
    shocks = result(1);
    double log_w_Q = as_scalar(result(2));

    if (!std::isinf(log_w_Q)) {
      log_w = log_w_B + log_w_Q;
    }
    n_tries++;
  }

  w = std::exp(log_w);

  arma::field<arma::mat> out(9);
  out(0) = arma::mat(1, 1, arma::fill::zeros); out(0)(0, 0) = w;
  out(1) = hyper;
  out(2) = B.t();
  out(3) = Q.t() * h_invp;
  out(4) = Q;
  out(5) = Sigma;
  out(6) = chol_Sigma * Q;
  out(7) = shocks;
  out(8) = repmat(sigma.t(), N, 1);

  return out;
}

// [[Rcpp::interfaces(cpp)]]
// [[Rcpp::export]]
Rcpp::List bsvar_sign_par_cpp(
    const int &p,
    const arma::mat &Y,
    const arma::mat &X,
    const arma::cube &sign_irf,
    const arma::mat &sign_narrative,
    const arma::mat &sign_B,
    const arma::field<arma::mat> &Z,
    const int &Nf,
    const Rcpp::List &prior,
    const int &max_tries = 10000,
    const int idx = 0
) {
  arma::field<arma::mat> draw = bsvar_sign_single_draw_cpp(
    p, Y, X, sign_irf, sign_narrative, sign_B, Z, Nf, prior, max_tries, idx
  );

  return List::create(
      _["w"]      = as_scalar(draw(0)),
      _["hyper"]  = draw(1),
      _["A"]      = draw(2),
      _["B"]      = draw(3),
      _["Q"]      = draw(4),
      _["Sigma"]  = draw(5),
      _["Theta0"] = draw(6),
      _["shocks"] = draw(7),
      _["sigma"]  = draw(8)
  );
}

// [[Rcpp::interfaces(cpp)]]
// [[Rcpp::export]]
Rcpp::List bsvar_sign_cpp(
    const int&        S,
    const int&        p,
    const arma::mat&  Y,
    const arma::mat&  X,
    const arma::cube& sign_irf,
    const arma::mat&  sign_narrative,
    const arma::mat&  sign_B,
    const arma::field<arma::mat>& Z,
    const int&        Nf,
    const Rcpp::List& prior,
    const bool        show_progress = true,
    const int         thin = 100,
    const int&        max_tries = 10000
) {
  
  std::string oo = "";
  if ( thin != 1 ) {
    oo      = bsvars::ordinal(thin) + " ";
  }
  
  // Progress bar setup
  double num_threads = 1;
  vec prog_rep_points = arma::round(arma::linspace(0, S / num_threads, 50));
  if (show_progress) {
    Rcout << "**************************************************|" << endl;
    Rcout << " bsvarSIGNs: Bayesian Structural VAR with sign,   |" << endl;
    Rcout << "             zero and narrative restrictions      |" << endl;
    Rcout << "**************************************************|" << endl;
    Rcout << " Progress of simulation for " << S << " independent draws" << endl;
    Rcout << " Press Esc to interrupt the computations" << endl;
    Rcout << "**************************************************|" << endl;
  }
  Progress bar(50, show_progress);
  
  const int  T = Y.n_rows;
  const int  N = Y.n_cols;
  const int  K = X.n_cols;
  
  mat        hypers = as<mat>(prior["hyper"]);
  
  vec        posterior_w(S);
  mat        posterior_hyper(hypers.n_rows, S);
  cube       posterior_A(N, K, S);
  cube       posterior_B(N, N, S);
  cube       posterior_Q(N, N, S);
  cube       posterior_Sigma(N, N, S);
  cube       posterior_Theta0(N, N, S);
  cube       posterior_shocks(N, T, S);
  cube       posterior_sigma(N, T, S);
  
  for (int s = 0; s < S; s++) {
    
    int idx = (hypers.n_cols > 1 ? hypers.n_cols - S + s : 0);
    
    arma::field<arma::mat> draw = bsvar_sign_single_draw_cpp(
      p, Y, X, sign_irf, sign_narrative, sign_B, Z, Nf, prior, max_tries, idx
    );
    
    posterior_w(s)            = as_scalar(draw(0));
    posterior_hyper.col(s)    = draw(1);
    posterior_A.slice(s)      = draw(2);
    posterior_B.slice(s)      = draw(3);
    posterior_Q.slice(s)      = draw(4);
    posterior_Sigma.slice(s)  = draw(5);
    posterior_Theta0.slice(s) = draw(6);
    posterior_shocks.slice(s) = draw(7);
    posterior_sigma.slice(s)  = draw(8);
    
    // Increment progress bar
    if (any(prog_rep_points == s)) bar.increment();
    
  } // END s loop
  
  return List::create(
    _["posterior"]  = List::create(
      _["w"]        = posterior_w,
      _["hyper"]    = posterior_hyper,
      _["A"]        = posterior_A,
      _["B"]        = posterior_B,
      _["Q"]        = posterior_Q,
      _["Sigma"]    = posterior_Sigma,
      _["Theta0"]   = posterior_Theta0,
      _["shocks"]   = posterior_shocks,
      _["sigma"]    = posterior_sigma
    )
  );
} // END bsvar_sign_cpp


